<section id="highlights" class="wrapper style2">
		<div class="title">Belépés</div>
<div style="margin: auto; width: 50%; border: 3px solid white; padding: 10px;">
	<form action = "?oldal=belep" method = "post">
      <fieldset>
        <legend>Bejelentkezés</legend>
        <br>
        <input type="text" name="felhasznalo" placeholder="felhasználó" required><br><br>
        <input type="password" name="jelszo" placeholder="jelszó" required><br><br>
        <input type="submit" name="belepes" value="Belépés">
        <br>&nbsp;
      </fieldset>
    </form>
	</div>
</section>
<section id="highlights" class="wrapper style3">
<div class="title">Regisztrálja magát,<br/> ha még nem felhasználó!</div>
	<div style="margin: auto; width: 50%; border: 3px solid white; padding: 10px;">
    <form action = "?oldal=regisztral" method = "post">
      <fieldset>
        <legend>Regisztráció</legend>
        <br>
        <input type="text" name="vezeteknev" placeholder="vezetéknév" required><br><br>
        <input type="text" name="utonev" placeholder="utónév" required><br><br>
        <input type="text" name="felhasznalo" placeholder="felhasználói név" required><br><br>
        <input type="password" name="jelszo" placeholder="jelszó" required><br><br>
        <input type="submit" name="regisztracio" value="Regisztráció">
        <br>&nbsp;
      </fieldset>
</div>