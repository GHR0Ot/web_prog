<!DOCTYPE html>

<?php
	//szerver oldali ellenőrzés példa

	if(!isset($_POST['nev']) || strlen($_POST['nev']) < 5)
	{
		exit("Hibás név: ".$_POST['nev']);
	}

	$re = '/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/';
	if(!isset($_POST['email']) || !preg_match($re,$_POST['email']))
	{
		exit("Hibás email: ".$_POST['email']);
	}

	if(!isset($_POST['szoveg']) || empty($_POST['szoveg']))
	{
		exit("Hibás szöveg: ".$_POST['szoveg']);
	}

	echo "<h2>Üzenet adatai: </h2>";
	echo "<pre>";
	echo "Név:  ".$_POST['nev'];
	echo "\nE-mail cím:  ".$_POST['email'];
	echo "\nÜzenet:  ".$_POST['szoveg'];
	echo "</pre>";
	//Adatbázisba feltöltés
	try{
	 $dbh = new PDO('mysql:host=linklocal;dbname=bead', 'root', '',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
     $dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
	 $sqlInsert = "insert into uzenetek(id, nev, mail, uzen)
                          values(0, :nick, :mailcim, :szovuzen)";
            $stmt = $dbh->prepare($sqlInsert); 
            $stmt->execute(array(':nick' => $_POST['nev'], ':mailcim' => $_POST['email'], ':szovuzen' => $_POST['szoveg'])); 
            if($count = $stmt->rowCount()) {
                $newid = $dbh->lastInsertId();
                echo "Az üzenet mentve.<br>";                     
                $ujra = false;
				$link="?oldal=uzenlista";
			echo "<a href=\"$link\" class=\"gomb\">Korábbi üzenetek</a>"; 
				
			} else {
                echo "Az üzenet mentése nem sikerült.<br>";
				
                $ujra = true;
            }
	}
	catch (PDOException $e) {
        $uzenet = "Hiba: ".$e->getMessage();
        $ujra = true;
    }      
	
?>