<section id="intro" class="wrapper style3">
					<div class="title"><?php if(isset($uzenet)) { ?>
            <h1><?= $uzenet ?></h1>
            <?php if($ujra) { ?>
                <a href="belepes.tpl.php">Próbálja újra!</a>
            <?php } ?>
        <?php } ?></div>
<section>
    