<?php
	$uzenet = array();
	
    // Űrlap ellenőrzés:
    if (isset($_POST['kuld'])) {
        //print_r($_FILES);
        foreach($_FILES as $fajl) {
            if ($fajl['error'] == 4);   // Nem töltött fel fájlt
            elseif (!in_array($fajl['type'], $MEDIATIPUSOK))
                $uzenet[] = " Nem megfelelő a " . $fajl['name'] . " nevű kép típusa!";
            elseif ($fajl['error'] == 1   // A fájl túllépi a php.ini -ben megadott maximális méretet
                        or $fajl['error'] == 2   // A fájl túllépi a HTML űrlapban megadott maximális méretet
                        or $fajl['size'] > $MAXMERET) 
                $uzenet[] = " Túl nagy a " . $fajl['name'] . " nevű kép mérete!";
            else {
                $vegsohely = $MAPPA.strtolower($fajl['name']);
                if (file_exists($vegsohely))
                    $uzenet[] = " Már létezik a " . $fajl['name'] . " nevű kép!";
                else {
                    move_uploaded_file($fajl['tmp_name'], $vegsohely);
                    $uzenet[] = ' A kép feltöltve ' . $fajl['name'] . ' néven!';
                }
            }
        }        
    }
    // Megjelenítés logika:
?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Galéria</title>
    <style type="text/css">
        label { display: block; }
		td { padding-left: 25px; padding-right: 15px; }
		.egybe { text-align: center; padding: 10px 0px 0px 0px; }
		h1 { text-align:center; }
		table { margin-left:auto; margin-right:auto; }
    </style>
</head>
<body>
    <h1>Feltöltés a galériába:</h1>
<?php
    if (!empty($uzenet))
    {
        echo '<ul>';
        foreach($uzenet as $u)
            echo "<li>$u</li>";
        echo '</ul>';
    }
?>
	<form action="?oldal=kepfeltoltes" method="post"
                enctype="multipart/form-data">
		<table>
		<tr>
		<td> <label>Első: </td>
           <td> <input type="file" name="elso" required>
        </label></td>
		</tr>
		<tr>
		<td>
        <label>Második:</td>
            <td><input type="file" name="masodik">
        </label>
		</td>
		</tr>
		<tr>
		<td>
        <label>Harmadik:</td>
           <td> <input type="file" name="harmadik">
        </label> </td>
		</tr>
		<tr>
		<td colspan="2" class="egybe">	
        <input type="submit" name="kuld">
		</td>
		</tr>
		</table>
      </form>    

