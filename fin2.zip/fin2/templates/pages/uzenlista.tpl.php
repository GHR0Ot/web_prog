<!DOCTYPE html>
<section id="intro" class="wrapper style3">
					<div class="title">Üzenetek listája</div>
	
<?php
	
	//Adatbázis lekérdezés
	try{
	 // Kapcsolódás
        $dbh = new PDO('mysql:host=localhost;dbname=bead', 'bead', 'xiUiukuUSLMDTagHA0dW',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        $dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
        
     // Adatok lekérése
        $sqlSelect = "select id, nev, uzen from uzenetek order by id desc";
		$sth = $dbh->prepare($sqlSelect);
		$sth->execute();
		$result = $sth->fetchAll();
		echo 	"<table>
				<tr>
				<th>Név</th>
				<th>Üzenet</th>
				</tr>"    ;

		foreach($result as $row)
		{
			echo "<tr>";
			echo "<td>" . $row['nev'] . "</td>";
			echo "<td>" . $row['uzen'] . "</td>";
		}

		echo "</tr>";
		echo "</table>";	
		
	}
	catch (PDOException $e) {
        $errormessage = "Hiba: ".$e->getMessage();
    }      
?>
	</section>