<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<link rel="stylesheet" href="./styles/tablazat.css" type="text/css">
	</head>
<body>
	<h1 class="cim">Üzenetek listája </h1>
<?php
	
	//Adatbázis lekérdezés
	try{
	 // Kapcsolódás
        $dbh = new PDO('mysql:host=localhost;dbname=beadando', 'root', '',
                        array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));
        $dbh->query('SET NAMES utf8 COLLATE utf8_hungarian_ci');
        
     // Adatok lekérése
        $sqlSelect = "select id, nev, uzen from uzenetek order by id desc";
		$sth = $dbh->prepare($sqlSelect);
		$sth->execute();
		$result = $sth->fetchAll();
		echo 	"<table>
				<tr>
				<th>Név</th>
				<th>Üzenet</th>
				</tr>"    ;

		foreach($result as $row)
		{
			echo "<tr>";
			echo "<td>" . $row['nev'] . "</td>";
			echo "<td>" . $row['uzen'] . "</td>";
		}

		echo "</tr>";
		echo "</table>";	
		
	}
	catch (PDOException $e) {
        $errormessage = "Hiba: ".$e->getMessage();
    }      
	
?>
	</body>
</html>