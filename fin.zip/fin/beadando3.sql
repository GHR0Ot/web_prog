
CREATE TABLE IF NOT EXISTS `uzenetek` (
  `id` int(11) NOT NULL auto_increment,
  `nev` varchar(50) NOT NULL,
  `mail` varchar(100) NOT NULL,
  `uzen` text NOT NULL,
  PRIMARY KEY (`id`)
) 
ENGINE = MYISAM
CHARACTER SET utf8 COLLATE utf8_general_ci;

INSERT INTO `uzenetek` (`id`, `nev`, `mail`, `uzen`) VALUES
(1, 'Testnevelés 1A', 'vmi@vmi.hu', 'Testing! Testing!');